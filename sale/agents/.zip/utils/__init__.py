from sale.utils.epsilon_decay import linearly_decaying_epsilon

__all__ = ['linearly_decaying_epsilon']